// proširuje apstraktnu klasu Server
public class Windows_Server extends Server{

    private final String WS = this.getClass().getSimpleName();

    public Windows_Server(){
        this.ip_adrs = "169.254.100.8";
        this.port_number = 20;

    }


    @Override
    public boolean establish_connection(String url, String usr, String password) {
        // ako svi ulazni stringovi nisu prazni ispis --> pogledati konzolni izlaz
        // if - else
        if (url.length()>0 && usr.length()>0 && password.length()>0) {
            System.out.println("Something specific for establishing connection with the Windows server...");
            System.out.println("Connection established to -> " + usr);
        
        }
        return false;
    }

    @Override
    public boolean close_connection(String url, String usr) {
        // ako svi ulazni stringovi nisu prazni ispis --> pogledati konzolni izlaz
        // if - else
        if (url.length()>0 && usr.length()>0) {
            System.out.println("Something specific for closing connection with the Windows server...");
            System.out.println("Connection closed for -> " + usr);
        }
        return false;
        
    }

    // dopuniti temeljem ostalih toString
    @Override
    public String toString() {
        return super.toString() + " {" + WS + "}";
        
    }

}


