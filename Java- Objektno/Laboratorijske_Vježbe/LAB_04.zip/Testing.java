// Uvoz ArrayList
import java.util.ArrayList;

public class Testing {

    public static void main(String[] args) {
        
        // kreiranje liste <Server> s referencom servers
        ArrayList<Server> servers = new ArrayList<>();
        
        // dodati objekt Virtual_Server u servers
        Virtual_Server virtual = new Virtual_Server();
        // dodati objekt Linux_Server u servers
        Linux_Server linux = new Linux_Server();
        // dodati objekt Windows_Server u servers
        Windows_Server win = new Windows_Server();
        
        servers.add(virtual);
        servers.add(linux);
        servers.add(win);
        
        // zadano - ne mijenjati
        String url = "conn:@dbs:1800:se";
        String usr = "user_007";
        String password = "5697845068409";
        // static method establishConnection
        Testing.establishConnection( servers, usr, url, password);
        
        // ne mijenjati ovaj dio ispisa
        System.out.println("******************************************************");
        // static method closeConnection
        Testing.closeConnection (servers, usr,url);
    }
    
    // static method establishConnection -> za svaki server poziva metodu za uspostavu veze s istim podacima
    // pogledati dijagrgam klasa
    static void establishConnection(ArrayList<Server> srvr, String usr, String url, String password) {
        Virtual_Server virtual = new Virtual_Server();
        Linux_Server linux = new Linux_Server();
        Windows_Server win = new Windows_Server();
        
        Server var = srvr.get(0);
        System.out.println(var);
        virtual.establish_connection(url, usr, password);
        Server var2 = srvr.get(1);
        System.out.println(var2);
        linux.establish_connection(url, usr, password);
        Server var3 = srvr.get(2);
        System.out.println(var3);
        win.establish_connection(url, usr, password);
    }

    // static method closeConnection -> za svaki server poziva metodu za zatvaranje veze s istim podacima
    // pogledati dijagram klasa
    static void closeConnection(ArrayList<Server> srvr, String usr, String url){
        Virtual_Server virtual = new Virtual_Server();
        Linux_Server linux = new Linux_Server();
        Windows_Server win = new Windows_Server();
        
        Server var = srvr.get(0);
        System.out.println(var);
        virtual.close_connection(url,usr);
        Server var2 = srvr.get(1);
        System.out.println(var2);
        linux.close_connection(url,usr);
        Server var3 = srvr.get(2);
        System.out.println(var3);
        win.close_connection(url,usr);
        
    }
}