// treba biti dijete klase Server
public class Virtual_Server extends Server       {

    private final String VS = this.getClass().getSimpleName();

    public Virtual_Server(){
        this.ip_adrs = "192.168.20.1";
        this.port_number = 443;

    }


    @Override
    public boolean establish_connection(String url, String usr, String password) {
        // ako svi ulazni stringovi nisu prazni ispis --> pogledati konzolni izlaz
        // if - else
        if (url.length()>0 && usr.length()>0 && password.length()>0) {
            System.out.println("Connection established to -> " + usr);
        }
        return false;
    }

    @Override
    public boolean close_connection(String url, String usr) {
        // ako svi ulazni stringovi nisu prazni ispis --> pogledati konzolni izlaz
        // if - else
        if(url.length()>0 && usr.length()>0) {
            System.out.println("Connection closed for -> " + usr);
        }
        return false;
    }

    // ne mijenjati
    @Override
    public String toString() {
        return super.toString() + " {" + VS + "}";
    }
}

