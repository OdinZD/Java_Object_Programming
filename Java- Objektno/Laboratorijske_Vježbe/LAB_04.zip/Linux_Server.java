// poširuje apstraktnu klasu Server
public class Linux_Server extends Server       {

    private final String LS = this.getClass().getSimpleName();

    public Linux_Server(){
        this.ip_adrs = "172.16.1.1";
        this.port_number = 80;

    }


    @Override
    public boolean establish_connection(String url, String usr, String password) {
        // ako svi ulazni stringovi nisu prazni ispis --> pogledati konzolni izlaz
        // if - else
        if (url.length()>0 && usr.length()>0 && password.length()>0) {
            System.out.println("Something specific for establishing connection with the Linux server...");
            System.out.println("Connection established to -> " + usr);
        }
        return false;
         
    }

    @Override
    public boolean close_connection(String url, String usr) {
        // ako svi ulazni stringovi nisu prazni ispis --> pogledati konzolni izlaz
        // if - else
        if (url.length()>0 && usr.length()>0) {
            System.out.println("Something specific for closing connection with the Linux server...");
            System.out.println("Connection closed for -> " + usr);
        }
        return false;
    }

    // ne mijenjati
    @Override
    public String toString() {
        return super.toString() + " {" + LS + "}";
    }

}
