//apstraktna klasa Robot - nadopuniti
public abstract class Robot {

    // staviti specifikatore pristupa
    String name;
    int id;

    // metoda turnOn
    protected void turnOn(){
        System.out.println(this.getClass().getSimpleName() + " is turned on!");
    }

    
    // metoda turnOff
    protected void turnOff() {
        System.out.println(this.getClass().getSimpleName() + " is turned off!");
    }
    // dvije apstraktne metode changeState i charge
    public abstract void changeState();
    public abstract void charge();
    
}
