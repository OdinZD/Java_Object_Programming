// klasa FlyingRobot - paziti koga proširuje

public class FlyingRobot extends Robot {
    
    // ima static field za automatsku dodjelu id-a
    public static int cnt;

    // konstruktor
    public FlyingRobot(String r1) {
        this.name = r1;
        this.id = cnt + 10;
        cnt = cnt + 10;
    }
    
    //override za tri metode - pogledati očekivani izlaz
    @Override
    public void changeState() {
        System.out.println(this.getClass().getSimpleName() + " can really fly autonomously...");
    }

    @Override
    public void charge() {
        System.out.println(this.getClass().getSimpleName() + " needs to be charged with the DC current charger!");
    }

    @Override
    public String toString() {
        System.out.println("<<<<<<<<< FlyingRobot >>>>>>>>>");
        System.out.println("[name = " + name + " <-> id = " + id + "]");
        return "[name = " + name + " <-> id = " + "]";
    }
}