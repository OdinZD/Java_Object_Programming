// klasa IndustrialRobot - paziti koga proširuje

public class IndustrialRobot extends Robot{
    
    // ima static field za automatsku dodjelu id-a
    public static int cnt;

    // konstruktor
    public IndustrialRobot(String r1) {
        this.name = r1;
        this.id = cnt + 10;
        cnt = cnt + 10;
    }
    
    //override za tri metode - pogledati očekivani izlaz
    @Override
    public void changeState() {
        System.out.println(this.getClass().getSimpleName() + " can't move from one spot to another but have remarkable state dynamics...");
    }

    @Override
    public void charge() {
        System.out.println(this.getClass().getSimpleName() + " is always connected to the electrical grid...");
    }

    @Override
    public String toString() {
        System.out.println("<<<<<<<<< IndustrialRobot >>>>>>>>>");
        System.out.println("[name = " + name + " <-> id = " + id + "]");
        return "[name = " + name + " <-> id = " + "]";
    }
    
    
}
