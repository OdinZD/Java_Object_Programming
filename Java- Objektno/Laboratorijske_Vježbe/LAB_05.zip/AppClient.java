// glavni kod - dobro pogledati dijagram klasa

import java.util.ArrayList;
import java.util.List;

public class AppClient {
    
    public static void main (String[] args) {
        
        IndustrialRobot inRobot = new IndustrialRobot("IR01");
        IndustrialRobot inRobot2 = new IndustrialRobot("IR02");
        IndustrialRobot inRobot3 = new IndustrialRobot("IR03");
        FlyingRobot flyRobot = new FlyingRobot("FR01");
        FlyingRobot flyRobot2 = new FlyingRobot("FR02");
        
        List<Robot> list = new ArrayList<>();
        list.add(inRobot);
        list.add(inRobot2);
        list.add(inRobot3);
        list.add(flyRobot);
        list.add(flyRobot2);
        
        AppClient.performActions(list);
    }
    
    private static void performActions(List<Robot> lista) {
        for (Robot var :lista){
            var.toString();
            var.turnOn();
            var.changeState();
            var.charge();
            var.turnOff();
        }
    }
    
}
