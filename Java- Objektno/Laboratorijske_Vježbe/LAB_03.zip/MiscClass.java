// osigurati uvoz za Scanner
import java.util.Scanner;

public class MiscClass {
    
    
    public static void dayHrMins(){
        // Scanner
        Scanner input = new Scanner(System.in);
        
       //Poruka za unos korisniku
        System.out.println("Unesite minute: ");
        
        //varijabla za skener 
        int min = input.nextInt();
        
        //Izlazna poruka korisniku
        System.out.println(min/24/60 + " d : " + min/60%24 + " h : " + min%60 + " m");
        
        input.close();
       
    }
}