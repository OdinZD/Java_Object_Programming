public class App {

    public static void main(String[] args) {

       // pozvati metodu klase MiscClass
      MiscClass.dayHrMins();
    }
}