public class App {

	public static void main(String[] args) {

	     // Definirajte float varijablu fl i postavite je na vrijednost 14.5, u drugom slučaju na 27.5
			
			
			
			float f1;
	        float threshold = 25f;
	        
	        if((f1 = 14.5f) >threshold) {
	        	
	        	System.out.println(f1 + " is greater than --> " + threshold);
	        	
	            
	       }else{
	        	
	        	System.out.println("Value: " +f1);
	            System.out.println("Threshold: " + threshold);
	            System.out.println("Less than threshold!");
	        }
	        

	        if((f1 = 27.5f) > threshold){
	        	System.out.println(f1 + " is greater than --> " + threshold);
	        		
	        }
	        
	}
}