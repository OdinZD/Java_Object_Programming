public class Car {
    
    private String Car;
    private long odom;
    public Car (String Car, long odom) {
        this.Car = Car;
        this.odom = odom;
        
    }
    public void info() {
        System.out.println("Odometer: " + odom + " km" + "," + " Car: " + Car);
        
    }
    
    public void updateOdom (long newOdom) {
        this.odom = this.odom + newOdom;
    }
}