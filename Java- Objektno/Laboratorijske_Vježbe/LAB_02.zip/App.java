// uvezite Scanner
import java.util.Scanner;

public class App {
    
    public static void main(String[] args) {
      
        Scanner sc = new Scanner(System.in);
		System.out.println("Enter car type: ");
		
		System.out.println("Enter car odometer: ");
		// Unos za obje vrijednosti Car i odometer
	    Car sc2 = new Car(sc.nextLine(), sc.nextLong());
		//Ispis info metode
		sc2.info();
		System.out.println("--------------------------------\n");
		System.out.println("Enter car odometer update value: ");
		// osigurajte unos nove prevaljene kilometraže
		sc2.updateOdom(sc.nextLong());
		// Ispis info metode nakon unose nove vrijednosti za updateOdom
		sc2.info();
		
	    sc.close();
	  
    } 
}