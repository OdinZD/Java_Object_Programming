// uvezi potrebne komponente iz pripadnih paketa
import java.util.ArrayList;
import java.util.Set;
import java.util.TreeSet;

public class App{
    
    public static void main(String[] args){
        
        // nova ArrayList
        ArrayList<String> lista = new ArrayList<String>();
        // popuni je s FST, SND, FST, ERT, WERT, WERT, RQA
        lista.add("FST");
        lista.add("SND");
        lista.add("FST");
        lista.add("ERT");
        lista.add("WERT");
        lista.add("WERT");
        lista.add("RQA");
        // ispis liste
        System.out.println(lista);
        // kreiraj novi TreeSet
        Set<String> setTree = new TreeSet<>();
        // dodaj sve iz prethodne liste u taj skup
        setTree.add("FST");
        setTree.add("SND");
        setTree.add("FST");
        setTree.add("ERT");
        setTree.add("WERT");
        setTree.add("WERT");
        setTree.add("RQA");
        // ispis za popunjeni TreeSet
        System.out.println(setTree);
    }
}