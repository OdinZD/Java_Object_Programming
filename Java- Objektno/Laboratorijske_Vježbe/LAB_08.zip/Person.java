// kopirati kod iz LAB_07
public class Person {

    protected String name;
    protected int id;
    // statičko polje tipa int s početnom vrijednosti = 10
   static int cnt = 10;
    
    
    // kreirati osnovni konstruktor
    public Person(){
        this.id = cnt;
    }

    public Person(String name){
        this.name = name;
        this.id = cnt;
        cnt++;
    }
    
    // ispsiuje toString
    public void info(){
        System.out.println(toString());
    }

    // ne trebate mijenjati!!!
    @Override
    public String toString() {
        return "\n" + this.getClass().getSimpleName() + ":\n" +
                "\tname = " + name + '\n' +
                " \tid = " + id + '\n';
    }
}