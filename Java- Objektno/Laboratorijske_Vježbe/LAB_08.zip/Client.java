// uvesti potrebne elemente 
import java.security.KeyStore.Entry;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;

public class Client{
    
    public static void main(String[] args){
        
        // struktura HashMap za spremanje parova ime pisca (key)
        
        // popis svih naslova pojedinog pisca (value)
        HashMap<String, Set<String>> hash = new HashMap<String, Set<String>>();
        // kreirati jednog pisca i dodati dva naslova
        Writer w1 = new Writer("Writer_01");
        // "Title_01_W1"
        w1.addAssociatedTitle("Title_01_W1");
        w1.titles.add("Title_01_W1");
        // "Title_02_W1"
        w1.addAssociatedTitle("Title_02_W1");
        w1.titles.add("Title_02_W1");
        //Ponavljanje unosa
        w1.addAssociatedTitle("Title_01_W1");
        w1.titles.add("Title_01_W1");
        // pozvati metodu writerInfo za topg pisca
        w1.writerInfo();
        // kreirati dugog pisca i dodati dva naslova
        Writer w2 = new Writer("Writer_02");
        // "Title_01_W2"
        w2.addAssociatedTitle("Title_01_ W2");
        w2.titles.add("Title_01_W2");
        // "Title_02_W2"
        w2.addAssociatedTitle("Title_02_W2");
        w2.titles.add("Title_02_W2");
        w1.addAssociatedTitle("Title_01_W1");
        w1.titles.add("Title_01_W1");
        
        
        w2.writerInfo();
        // staviti podatke za drugog pisca u HashMap --> pogledati API
        hash.put("Writer_01", w1.titles);
        hash.put("Writer_02", w2.titles);
        // pozvati metodu listAll4Map
        
        listAll4Map(hash);
        
    }
    
    // dopuniti prema traženom izlazu - paziti što je ulazni argument
    
    private static <key, value> void listAll4Map(HashMap<key, value> map){
        // ispisati sve parove (key, value)
        for( key key : map.keySet()) {
            System.out.println(key + ": " + "\n" + map.get(key));
            System.out.println("****************************" + "\n");
            
        }
        
        
    }
}