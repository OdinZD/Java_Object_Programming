// uvoz za strukturu mape koja se traži 
import java.util.TreeMap;
public class App {

    public static void main(String[] args) {
        // ne mijenjati
        String filepath = "UsersFile.bin";
        // prvi User -> "Name_01", "mail_01@company.org"
        User prviUser = new User("Name_01", "mail_01@company.org");
        // drugi User -> "Name_02", "mail_02@network.net"
        User drugiUser = new User("Name_02", "mail_02@network.net");
        // treći User -> "Name_03", "mail_03@organization.com"
        User treciUser = new User("Name_03", "mail_03@organization.com");
        // TreeMap users 
        TreeMap<Integer, User> users = new TreeMap<Integer, User>();
        
        // staviti sve korisnike u tu mapu
        users.put(prviUser.getId(), prviUser);
        users.put(drugiUser.getId(), drugiUser);
        users.put(treciUser.getId(), treciUser);
        
        
        
        // spremi mapu u datoteku -> filepath
        SerDeserial.saveUsr2File(filepath, users);
        
       
       
        // rekonstruiraj podatke iz datoteke 
        System.out.println("\n<<<<<<<<<<<<<<<<<< All from file >>>>>>>>>>>>>>>>>>");
        SerDeserial.readUsr4File(filepath);
    }
}