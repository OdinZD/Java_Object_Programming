import java.io.*;
import java.util.TreeMap;
import java.util.Map;

public class SerDeserial {

    public static void saveUsr2File(String filepath, TreeMap<Integer, User> usrs){
        try {
            FileOutputStream fileOut = new FileOutputStream(filepath);
		    ObjectOutputStream out = new ObjectOutputStream(fileOut);
		    out.writeObject(usrs);
		    out.close();
		    System.out.println("All saved to the file -> " + filepath);
		}catch (IOException e) {
		    e.printStackTrace();
		}
    }


    public static void readUsr4File(String filepath){
        
        // u bloku finally ispisati sve iz rekonstruirane mape
        // pogledati traženi konzolni izlaz
        TreeMap<Integer, User> tree = null;
		  try {
		      FileInputStream fileIn = new FileInputStream(filepath);
		      ObjectInputStream in = new ObjectInputStream(fileIn);
		      tree = (TreeMap<Integer, User>) in.readObject();
		      in.close();
		      fileIn.close();
		}catch (IOException i) {
		      i.printStackTrace();
		}catch (ClassNotFoundException c) {
		      System.out.println("User class not found!");
		      c.printStackTrace();
		}
		for (Map.Entry<Integer, User> tr : tree.entrySet()) {
		    User user = tr.getValue();
		    System.out.println(user.toString());
		}
		    	
    }
}
