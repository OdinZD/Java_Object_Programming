public class Client {

    public static void main(String[] args) {
        
        // kreirati objekt Person s imenom "Marijan"
        Person osoba1 = new Person("Marijan");
        // pozvati info metodu tog objekta
        osoba1.info();
        // kreirati objekt klase Writer s imenom "Writere_01"
        Writer w1 = new Writer("Writer_01");
        // dodati naslov za w1 "Title_01_W1"
        w1.addAssociatedTitle("Title_01_W1");
        w1.titles.add("Title_01_W1");
        // dodati naslov za w1 "Title_02_W1"
        w1.addAssociatedTitle("Title_02_W1");
        w1.titles.add("Title_02_W1");
        // ponoviti dodavanje naslova "Title_01_W1" za w1 
        w1.addAssociatedTitle("Title_01_W1");
        w1.titles.add("Title_01_W1");
        // pozvati writerInfo za w1
        w1.writerInfo();
        // kreirati objekt klase Writer s imenom "Writer_103"
        Writer w2 = new Writer("Writer_103");
        // dodati naslov za w2 "Title_01 for W2"
        w2.addAssociatedTitle("Title_01 for W2");
        w2.titles.add("Title_01 for W2");
        // dodati naslov za w2 "Title_02 for W2"
        w2.addAssociatedTitle("Title_02 for W2");
        w2.titles.add("Title_02 for W2");
        // dodati naslov za w2 "Title_03 for W2"
        w2.addAssociatedTitle("Title_03 for W2");
        w2.titles.add("Title_03 for W2");
        // pozvati writerInfo za w2
        w2.writerInfo();
        // kreirati novi objekt klaseWriter s imenom "Writer_007"
        Writer w3 = new Writer("Writer_007");
        // pozvati writerInfo za taj objekt
        w3.writerInfo();


    }
}