// osigurati odgovarajuće uvoze
import java.util.Set;
import java.util.TreeSet;


public class Writer extends Person{
    
    // polje titles tipa Set
    protected Set<String> titles;

    
    public Writer(String name){
        this.name = name;
        this.id = cnt;
        // inicijalizirati prazni TreeSet za polje titles
        titles = new TreeSet<>();
        // inkermentirati cnt za 10
        cnt += 10;
    }

    public void writerInfo(){
        // pozvati metodu roditelja info()
        info();
        System.out.println("Titles:");
        // ako je skup titles nije prazan ispis svih naslova u njemu
        // u suprotnom ostaviti poruku koja je navedena
        if(titles.isEmpty() ==false){
            // for-each petlja
            for (String k : titles) {
                System.out.println("\t" +k);
            }
            
            //izvan petlje - ostaviti!!!
            System.out.println();
        } else {
            // ne mijenjati else dio!!!
            System.out.println("\tThere are no titles associated with this writer!\n");

        }
    }

    // metoda za dodavanje naslova vezanog uz konkretnog pisca
    public void addAssociatedTitle(String title){
        // provjeri postoji li već u skupu -> pogledati API za TreeSet
        // dopuniti samo uvjetni izraz if!!!
        if( titles.contains(title) == false){
            System.out.println("Title has been successfully added!");
        } else {
            System.out.println("Title already is associated with this writer!");
        }
    }

    // getters za titles
    public Set<String> getTitles(){
        return titles;
    }

    // getters za name
    public String getName() {
        return name;
    }


}
