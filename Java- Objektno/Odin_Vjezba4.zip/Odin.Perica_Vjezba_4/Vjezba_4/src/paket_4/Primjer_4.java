package paket_4;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Arrays;

public class Primjer_4 {

	public static void main(String[] args) {
		
		
		Primjer_4_FleetVehicles flt = new Primjer_4_FleetVehicles();
		
		Primjer_4_Vehicle car1 = new Primjer_4_Vehicle();																		// XX
		Primjer_4_Vehicle car2 = new Primjer_4_Vehicle();																		// XX
		Primjer_4_Vehicle car3 = new Primjer_4_Vehicle();																		// XX
		ArrayList<Primjer_4_Vehicle> vhl1 = new ArrayList<>();
		
		Primjer_4_Vehicle car4 = new Primjer_4_Vehicle();																		// XX
		Primjer_4_Vehicle car5 = new Primjer_4_Vehicle();																		// XX
		Primjer_4_Vehicle car6 = new Primjer_4_Vehicle();																		// XX
		
		Collections.addAll(vhl1, car1, car2, car3);																				// XX
		
		
		System.out.println(); 
		
		
		System.out.println("///////////////// Snd listing /////////////////");
		
		System.out.println(Arrays.toString(Primjer_4_FleetVehicles));																				// XX

		
	}}