package paket_4;

public class Zadatak_1_Semafor {									
	private int zeleno = 1;
	private int crveno = 0;
	private int zuto = 2;
	public int getZeleno() {
	return zeleno;
	}
	public void setZeleno(int zeleno) {
	this.zeleno = zeleno;
	}
	public int getCrveno() {
	return crveno;
	}
	public void setCrveno(int crveno) {
	this.crveno = crveno;
	}
	public int getZuto() {
	return zuto;
	}
	public void setZuto(int zuto) {
	this.zuto = zuto;
	}
	public void stanje(int num) {
	switch (num) {
	case 1:
	System.out.println("Zeleno - svima prolaz : kod " + zeleno);
	break;
	case 2:
	System.out.println("Žuto - priprema : kod " + zuto);
	break;
	case 0:
	System.out.println("Crveno - svi stoj : kod " + crveno);
	break;
	default: System.out.println("Pogre�an kod semafora - potrebni kodovi su 0, 1 ili 2.");
}}}