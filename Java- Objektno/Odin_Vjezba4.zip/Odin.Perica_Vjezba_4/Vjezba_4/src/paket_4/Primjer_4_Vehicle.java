package paket_4;

public class Primjer_4_Vehicle {							
	private String brandName;
	private int vehID;
	private String model;
	private String vehRegistrationPlate;
	private String prodYear;
	public Primjer_4_Vehicle() {
	}
	public Primjer_4_Vehicle(String bName, String model, int ID, String regPla, String year) {
	this.brandName = bName;
	this.model = model;
	this.vehID = ID;
	this.vehRegistrationPlate = regPla;
	this.prodYear = year;
	}
	
	
	public String getBrandName() {
	return brandName;
	}
	public void setBrandName(String brandName) {
	this.brandName = brandName;
	}
	public int getVehicleID() {
	return vehID;
	}
	public void setVehicleID(int vehID) {
	this.vehID = vehID;
	}
	public String getModel() {
	return model;
	}
	public void setModel(String model) {
	this.model = model;
	}
	public String getVehicleRegistrationPlate() {
	return vehRegistrationPlate;
	}
	public void setVehicleRegistrationPlate(String vehRegistrationPlate) {
	this.vehRegistrationPlate = vehRegistrationPlate;
	}
	public String getProdYear() {
	return prodYear;
	}
	public void setProdYear(String prodYear) {
	this.prodYear = prodYear;
	}
	
	public void vehInfo(){
	System.out.println("Car brand: " + getBrandName() + ", vehicle ID: " + getVehicleID() + ", model: " + getModel()
	+ ", vehregistration plate: " + getVehicleRegistrationPlate() + ", production year: " + getProdYear());
}}