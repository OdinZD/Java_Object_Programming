package paket_4;

import paket_4_1.Primjer_2_PastetaTuna;

public class Primjer_2_Meni {										
	private Primjer_2_JuhaPoriluk jp = new Primjer_2_JuhaPoriluk();
	private Primjer_2_PastetaTuna pt = new Primjer_2_PastetaTuna();
	public Primjer_2_Meni() { 										
	jp.meniInfoJP();
	pt.meniInfoJP();
	}
	public void cijenaSimul(Primjer_2_JuhaPoriluk pr1, Primjer_2_PastetaTuna pr2) {
	int sum = pr1.getJedCijena() + pr2.getJedCijena();
	System.out.println("Cijena za jednu juhu i jednu pa�tetu: " + sum);
}}