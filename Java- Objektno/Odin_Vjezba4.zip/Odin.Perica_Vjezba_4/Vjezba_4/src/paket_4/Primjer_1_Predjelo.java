package paket_4;

public class Primjer_1_Predjelo {							
	String naziv;
	String vrsta;
	int kolicina;
	public void Predjelo() {
	System.out.println("Kreiram objekt klase Predjelo");
	}
	public void pojediPredjelo(String naziv) {
	System.out.println("Jedem predjelo: " + naziv);
	}
	
	String pojeoSamKolPredjela(String naziv, String vrsta, int kolicina) {
	String predjeloInfo = naziv + " " + vrsta + " predjela i to u sljede�oj koli�ini " + kolicina;
	return predjeloInfo;
}}