package paket_4;

import java.util.Date;

public class Primjer_A_Vehicle {							

	
	protected String brand = "BMW";						
	protected String model = "318";						
	protected Date year = new Date();					
	private int vehicleID = 123456;						
	
	
	public void Vehicle(String brand){
	System.out.println("A Vehicle from the brand " + brand + " created intentionally!");
	}
	
	
	public void start(){
	System.out.println("Vehicle engine has been started!");
	}
	public void stop(){
	System.out.println("Vehicle engine stopped!");
	}
	public String info(){
	String infoStr;
	infoStr = "Brand: " + brand + ", model: " + model + ", year: " + year + ", ID:" + vehicleID;
	return infoStr;
}}