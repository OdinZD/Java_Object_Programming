package paket_4;

public class Primjer_A {

	public static void main(String[] args) {
		
		
		Primjer_A_Vehicle automobil = new Primjer_A_Vehicle();	
		automobil.Vehicle(null);								
		automobil.start();										
		automobil.stop();										
		System.out.print(automobil.info());						
	}}