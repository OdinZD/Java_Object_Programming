package paket_4;

public class Primjer_5 {

	public static void main(String[] args) {
		
		
		Primjer_5_Zgrada zg = new Primjer_5_Zgrada();
		zg.setAddrs("Adresa za zgradu br. 14");
		zg.zgradaInfo();
		
		 
		
	}}