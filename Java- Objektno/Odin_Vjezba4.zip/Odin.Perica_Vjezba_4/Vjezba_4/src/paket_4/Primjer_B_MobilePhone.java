package paket_4;

public class Primjer_B_MobilePhone {									
	private String mobNum;
	private String brand;
	private String model;
	private Primjer_B_Employee emp;
	public String getMobNum() {
	return mobNum;
	}
	public void setMobNum(String mobNum) {
	this.mobNum = mobNum;
	}
	public String getBrand() {
	return brand;
	}
	public void setBrand(String brand) {
	this.brand = brand;
	}
	public String getModel() {
	return model;
	}
	public void setModel(String model) {
	this.model = model;
	}
	public Primjer_B_Employee getEmp() {
	return emp;
	}
	public void setEmp(Primjer_B_Employee emp) {
	this.emp = emp;
	}
	public void mobInfo() {
	System.out.println(" ////////////////////////////////////////////////////////////////////////////");
	System.out.println("Brand: " + getBrand() + ", model: " + getModel() + " , mobNum: " + getMobNum());
	System.out.println("Owner - employee: " + getEmp().getNameSurname());
	System.out.println(" ///////////////////////////////////////////////////////////////////////////");
}}