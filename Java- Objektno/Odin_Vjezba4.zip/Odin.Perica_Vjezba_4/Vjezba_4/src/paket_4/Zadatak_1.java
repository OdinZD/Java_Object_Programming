package paket_4;

public class Zadatak_1 {

	public static void main(String[] args) {
		
		
		Zadatak_1_ManualProgramSemafor mps = new Zadatak_1_ManualProgramSemafor();
		Zadatak_1_Semafor smf = new Zadatak_1_Semafor();
		int probni = 1;
		smf.stanje(probni);
		mps.stanjeManual(mps.stanjeNovo());
		
		
	}}