package paket_4;

import paket_4_1.Primjer_1_Desert;
import paket_4_1.Primjer_1_GlavnoJelo;

public class Primjer_1 {
	
	public static void main(String[] args) {
		Primjer_1_Predjelo predjelo = new Primjer_1_Predjelo();							
		Primjer_1_GlavnoJelo glavno = new Primjer_1_GlavnoJelo();						
		Primjer_1_Desert desert = new Primjer_1_Desert();								
		
		predjelo.pojediPredjelo("Juha od poriluka"); 	
		System.out.println(predjelo.pojeoSamKolPredjela("Paštete", "Tunjevina", 3));	
		System.out.println(glavno.toString());													
		desert.pojediDesert("Torta");
		System.out.println(desert.pojeoSamKolDeserta("Sladoled", "Jagoda", 2));
	}}