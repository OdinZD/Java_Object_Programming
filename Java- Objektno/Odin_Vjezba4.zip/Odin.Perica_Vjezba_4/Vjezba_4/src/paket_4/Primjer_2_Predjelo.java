package paket_4;

import java.util.Date;																
import java.util.Scanner;															
import java.text.SimpleDateFormat;													
import java.text.DateFormat;														
import java.text.ParseException;													

public class Primjer_2_Predjelo {													
	protected String naziv = "predjelo";
	protected String vrsta;
	protected int kolicina;
	private Date uvedenoOdGodine;
	public void Predjelo() {
	System.out.println("Kreiram objekt klase Predjelo");
	}
	public void pojediPredjelo(String naziv) {
	System.out.println("Jedem predjelo: " + naziv);
	}
	public String pojeoSamKolPredjela(String naziv, String vrsta, int kolicina) {
	String predjeloInfo = naziv + " " + vrsta + " predjela i to u sljede�oj koli�ini " + kolicina;
	return predjeloInfo;
	}
	public String getUvedenoGodine() {												
	String date;
	DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
	date = df.format(uvedenoOdGodine);
	return date;
	}
	public void setUvedenoOdGodine() throws ParseException {
	Scanner sc = new Scanner(System.in);
	DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
	System.out.println("Please enter the date in the form dd-MM-yyyy:");
	String date;
	date = sc.nextLine();
	uvedenoOdGodine = df.parse(date);
	sc.close();
	}
	public void infoDate() {
	System.out.println("Predjelo je u ovaj restoran uvedeno od: " + uvedenoOdGodine);	
}}