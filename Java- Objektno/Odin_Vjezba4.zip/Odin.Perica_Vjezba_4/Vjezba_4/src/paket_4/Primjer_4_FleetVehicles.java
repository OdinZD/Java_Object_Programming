package paket_4;

import java.util.ArrayList;

public class Primjer_4_FleetVehicles {									
	private String company;
	private int compID;
	private ArrayList<Primjer_4_FleetVehicles> vehicles = new ArrayList<>();
	
	
	public String getCompanyName() {
	return company;
	}
	public void setCompanyName(String company) {
	this.company = company;
	}
	public int getCompanyID() {
	return compID;
	}
	public void setCompanyID(int compID) {
	this.compID = compID;
	}
	
	
	public void setVehList(ArrayList<Primjer_4_Vehicle> vhcls) {
	
		for (int i = 0; i < 0; i++){
			vhcls.add(new Primjer_4_Vehicle());
	}}
	
	
	
	
	public void listAllVehicles() {
	
	System.out.println(Primjer_4_Vehicle);
}}