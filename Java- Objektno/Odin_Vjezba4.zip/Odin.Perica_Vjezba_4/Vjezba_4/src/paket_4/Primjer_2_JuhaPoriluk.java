package paket_4;

import java.util.concurrent.ThreadLocalRandom;

public class Primjer_2_JuhaPoriluk extends Primjer_2_Predjelo{		
	
	private static String uvedenaOdGod = "17-08-1988";
	private static int jedCijena = 30;
	
	
	public Primjer_2_JuhaPoriluk() {                                 
	setNaziv();
	setVrsta();
	setKolicina();
	infoJuhaPoriluk();
	System.out.println(" /////////////////////////////////////");
	}
	
	
	private void setNaziv() {
	naziv = "Juha";
	}
	public String getNaziv() {
	return naziv;
	}
	public String getVrsta() {
	return vrsta;
	}
	private void setVrsta() {
	vrsta = "od poriluka";
	}
	public void setKolicina() {
	this.kolicina = ThreadLocalRandom.current().nextInt(1, 3);
	}
	public int getKolicina() {
	return kolicina;
	}
	public void infoJuhaPoriluk() {
	System.out.println("Predjelo je: " + getNaziv() + " " + getVrsta() + " " + getKolicina() + " tanjura.");
	System.out.println("Uvedeno od: " + Primjer_2_JuhaPoriluk.uvedenaOdGod);
	}
	public void meniInfoJP() {
	System.out.println("Predjelo je: " + getNaziv() + " " + getVrsta() + " | cijena: " + Primjer_2_JuhaPoriluk.jedCijena + " kn.");
	}
	public int getJedCijena() {
	return Primjer_2_JuhaPoriluk.jedCijena;
}}
