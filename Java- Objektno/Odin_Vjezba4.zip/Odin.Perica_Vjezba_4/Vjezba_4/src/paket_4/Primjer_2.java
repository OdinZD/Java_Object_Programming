package paket_4;

import paket_4_1.Primjer_2_Desert;
import paket_4_1.Primjer_2_GlavnoJelo;
import paket_4_1.Primjer_2_PastetaTuna;

public class Primjer_2 {

	public static void main(String[] args) {
		Primjer_2_Meni meni = new Primjer_2_Meni();
		System.out.println("****************************");
		Primjer_2_JuhaPoriluk jp = new Primjer_2_JuhaPoriluk();
		Primjer_2_PastetaTuna pt = new Primjer_2_PastetaTuna();
		meni.cijenaSimul(jp, pt);
		Primjer_2_Predjelo predjelo = new Primjer_2_Predjelo();
		Primjer_2_GlavnoJelo glavno = new Primjer_2_GlavnoJelo();
		Primjer_2_Desert desert = new Primjer_2_Desert();
		predjelo.pojediPredjelo("Juha od poriluka");
		System.out.println(predjelo.pojeoSamKolPredjela("Pa�tete", "Tunjevina", 3));
		System.out.println(glavno.toString());
		desert.pojediDesert("Torta");
		System.out.println(desert.pojeoSamKolDeserta("Sladoled", "Jagoda", 2));
		
		System.out.println("\n");
		System.out.println("Zanima nas neki podatak od klase Predjelo: " + predjelo.naziv);
		
		
		
		predjelo.infoDate();
	}}