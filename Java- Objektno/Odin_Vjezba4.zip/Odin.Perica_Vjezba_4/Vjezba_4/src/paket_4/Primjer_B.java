package paket_4;

public class Primjer_B {

	public static void main(String[] args) {
		

	Primjer_B_Employee emp1 = new Primjer_B_Employee("Tony", "Maarketing");
	Primjer_B_MobilePhone mp = new Primjer_B_MobilePhone();
	mp.setBrand("Samsung");
	mp.setMobNum("+385912342344532");
	mp.setModel("S9+");
	mp.setEmp(emp1);
	emp1.setMob(mp);
	mp.mobInfo();
	System.out.println(emp1.getNameSurname() + " mobNum: " + emp1.getMob().getMobNum());
	System.out.println(emp1.getNameSurname() + " mob model: " + emp1.getMob().getModel());
}}