package paket_4;

public class Primjer_B_Employee {									
	private String nameSurname;
	private int emplID = 0;
	private String department;
	private Primjer_B_MobilePhone mob;
	public Primjer_B_Employee() {
	}
	public Primjer_B_Employee(String name, String department) {
	emplID++;
	this.nameSurname = name;
	this.department = department;
	}
	public String getNameSurname() {
	return nameSurname;
	}
	public void setNameSurname(String nameSurname) {
	this.nameSurname = nameSurname;
	}
	public int getEmplID() {
	return emplID;
	}
	public void setEmplID(int emplID) {
	this.emplID = emplID;
	}
	public String getDepartment() {
	return department;
	}
	public void setDepartment(String department) {
	this.department = department;
	}
	public Primjer_B_MobilePhone getMob() {
	return mob;
	}
	public void setMob(Primjer_B_MobilePhone mob) {
		this.mob = mob;
}}