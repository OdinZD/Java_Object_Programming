package paket_4;

import java.util.concurrent.ThreadLocalRandom;

public class Zadatak_1_ManualProgramSemafor {								
	Zadatak_1_Semafor smf = new Zadatak_1_Semafor();
	private int[] stNovo = new int[3];
	private int cnt = 0;
	public int[] stanjeNovo() {
	for (int i = 0; i < 3; i++) {
	stNovo[i] = ThreadLocalRandom.current().nextInt(0, 9);
	}
	return stNovo;
	}
	public void stanjeManual(int[] stn) {
	for (int i = 0; i < 3; i++) {
	smf.stanje(stn[i]);
	System.out.println("******************************************");
	}
	for(int st:stn) {
	System.out.println("Novo stanje za " + cnt + " jeste: " + st);
	cnt++;
}}}