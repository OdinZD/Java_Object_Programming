package paket_4_1;										

public class Primjer_2_Desert {							
	String naziv;
	String vrsta;
	int kolicina;
	public void Desert() {
	System.out.println("Kreiram objekt klase Desert");
	}
	public void pojediDesert(String naziv) {
	System.out.println("Jedem desert: " + naziv);
	}
	
	public String pojeoSamKolDeserta(String naziv, String vrsta, int kolicina) {
		String predjeloInfo = naziv + " " + vrsta + " deserta i to u sljede�oj kolicini " + kolicina;
		return predjeloInfo;
}}