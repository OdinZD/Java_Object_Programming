package paket_4_1;													

import java.util.concurrent.ThreadLocalRandom;
import paket_4.Primjer_2_Predjelo;

public class Primjer_2_PastetaTuna extends Primjer_2_Predjelo {		
	
	private static String uvedenaOdGod = "22-12-1997";
	private static int jedCijena = 70;
	
	
	public Primjer_2_PastetaTuna() {								
	setNaziv();
	setVrsta();
	setKolicina();
	infoPastetaTuna();
	System.out.println(" /////////////////////////////////////");
	}
	
	
	public void setNaziv() {
	this.naziv = "Pa�teta";
	}
	public void setVrsta() {
	this.vrsta = "od tune";
	}
	public void setKolicina() {
	this.kolicina = ThreadLocalRandom.current().nextInt(1, 3);
	}
	public String getNaziv() {
	return naziv;
	}
	public String getVrsta() {
	return vrsta;
	}
	public int getKolicina() {
	return kolicina;
	}
	public void infoPastetaTuna() {
	System.out.println("Predjelo je: " + getNaziv() + " " + getVrsta() + " " + getKolicina() + " tanjura.");
	System.out.println("Uvedeno od: " + Primjer_2_PastetaTuna.uvedenaOdGod);
	}
	public void meniInfoJP() {
	System.out.println("Predjelo je: " + getNaziv() + " " + getVrsta() + " | cijena: " + Primjer_2_PastetaTuna.jedCijena + " kn");
	}
	public int getJedCijena() {
	return Primjer_2_PastetaTuna.jedCijena;
}}