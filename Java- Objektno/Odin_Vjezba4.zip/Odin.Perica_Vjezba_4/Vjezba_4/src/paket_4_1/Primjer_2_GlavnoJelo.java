package paket_4_1;											

public class Primjer_2_GlavnoJelo {							
	
	public void GlavnoJelo() {
	System.out.println("Rije�eno i glavno jelo :-)");
}}