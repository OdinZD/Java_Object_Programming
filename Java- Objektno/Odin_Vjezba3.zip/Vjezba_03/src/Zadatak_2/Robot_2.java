package Zadatak_2;

import java.util.Arrays;
import java.util.concurrent.ThreadLocalRandom;

public class Robot_2 {

	private int ID;
	private String name;
	int[][] array = new int[5][4];

	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public void walk() {
		System.out.println("I roboti znaju hodati");
	}

	public static int factJel(int broj) {

		if (broj == 1)
			return 1;
		if (broj == 0)
			return 0;
		return factJel(broj - 1) * broj;

	}

	public void fillArr() {

		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array[0].length; j++) {
				array[i][j] = ThreadLocalRandom.current().nextInt(1, 99);
			}
		}
	}

	public void printArr() {
		
		for(int[] item : array) {
			System.out.println(Arrays.toString(item));
		}
	}
}