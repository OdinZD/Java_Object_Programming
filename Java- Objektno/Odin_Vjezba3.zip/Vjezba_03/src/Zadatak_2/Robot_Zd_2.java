package Zadatak_2;

public class Robot_Zd_2 {

	public static void main(String[] args) {
		Robot_2 rbt = new Robot_2();
		
		rbt.fillArr();
		rbt.printArr();

	}

	

}
