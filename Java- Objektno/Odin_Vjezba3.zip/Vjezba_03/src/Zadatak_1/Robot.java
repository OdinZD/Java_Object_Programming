package Zadatak_1;
//Kreirajte klasu Robot koja ima dva privatna atributa ID tipa int i name tipa String. 
//Od metoda klasa treba imati pristupne metode za navedene atribute i metodu walk koja ispisuje poruku I roboti znaju hodati. 
//U drugom dijelu zadatka trebate kreirati metodu u klasi Robot kojom robot može dati odgovor 
//na pitanje o vrijednosti faktorijele proizvoljnog prirodnog broja n (metoda factJel). 
//U glavnom dijelu programa kreirajte jedan objekt klase Robot, postavite mu ID i željeno ime, 
//te mu predajte poruku da šeta. Na kraju za zadani prirodni broj n upitajte robota koja je njegova vrijednost faktorijele.
//Pomoć za određivanje binomnih koeficijenata
//faktorijel
// if k=0 or k=n
//	if 0<k<n
//Osnovna ideja rekurzivnih algoritama je pronaći jednostavni zapis/oblik čijim ponavljanjem 
//se može riješiti cijeli problem uz poznavanje uvjeta zaustavljanja (tzv. granični slučaj).

public class Robot {
	
	private int ID;
	private String name;
	
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public void walk() {
		System.out.println("I roboti znaju hodati");
	}
	
	public static int factJel(int broj) {
		
		if (broj == 1)
			return 1;
		if (broj == 0)
			return 0;
		return factJel(broj - 1) * broj;
		
	}
}