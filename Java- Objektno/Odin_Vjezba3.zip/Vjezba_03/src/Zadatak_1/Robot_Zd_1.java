package Zadatak_1;

public class Robot_Zd_1 {

	public static void main(String[] args) {
		Robot rbt = new Robot();
		
		rbt.setID(2511);
		rbt.setName("Yuma");
		
		rbt.walk();
		System.out.println("Vrijednost factJel broj 7 je:" + Robot.factJel(7));
		

	}

}
