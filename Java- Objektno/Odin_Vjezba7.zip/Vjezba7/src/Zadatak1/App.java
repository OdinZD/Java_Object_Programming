package Zadatak1;

import java.util.ArrayList;
import java.util.Collections;

public class App {
    public static void main(String[] args) {

        ArrayList<String> lista = new ArrayList<String>(); // lista niza

        lista.add("auto"); // dodajemo elemente tipa String
        lista.add("svemirski brod");
        lista.add("avion");
        lista.add("helikopter");
        lista.add("jedrilica");
        lista.add("gliser");
        lista.add("romobil");
        lista.add("bicikla");

        Collections.sort(lista, new SilazniLengthStrComparator());

        System.out.println("++++ Ispis po velicini stringa ++++");
        System.out.println("++++ Od veceg prema manjem ++++");
        for (String item : lista) { // ispis po velicini stringa
            System.out.println(item);
        }

    }
}
