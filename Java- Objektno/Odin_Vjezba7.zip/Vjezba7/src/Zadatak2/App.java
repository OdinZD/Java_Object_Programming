package Zadatak2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class App {

    private static ArrayList <Integer> list1 = new ArrayList<>();
    private static ArrayList <Integer> list2 = new ArrayList<>();

    public static void main(String[] args) {

        list1.addAll(genRandNum(5));

        Collections.sort(list1);
        System.out.println("++++ Sortirano ++++");
        for (Integer item : list1) {
            System.out.println(item);
        }

        System.out.println("++++ Sortirano silazno ++++");
        // Anonimna klasa za slucaj sortiranja obrnutim redoslijedom
        // Kreiranje ove klase: treba ispisati Collections.sort(lista..., a zatim add unimplemented methods)
        Collections.sort(list1, new Comparator<Integer>() {

                    @Override
                    public int compare(Integer o1, Integer o2) {
                        if (o1 > o2) {
                            return -1;
                        } else if (o1 < o2) {
                            return 1;
                        } else {
                            return 0;
                        }
                    }
                }
        );

        for (Integer item : list1) {
            System.out.println(item);
        }
    }

    // Popunjavanje liste s posebno kreiranom metodom
    private static ArrayList<Integer> genRandNum(int num) {

        int min = 10;
        int max = 1000;

        while (num > 0) {

            list2.add(min + (int)(Math.random() * ((max - min) + 1)));
            num -= 1;
        }
        return list2;
    }

}
