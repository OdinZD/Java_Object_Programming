package Zadatak5;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class App {

    public static void main(String[] args) {

        LinkedList<String> vehicles = new LinkedList <> ();
        ListProcessing listproc = new ListProcessing();

        vehicles.add("car");
        vehicles.add("helicopter");
        vehicles.add("electronic bike");
        vehicles.add("truck");
        vehicles.add("motorcycle");
        vehicles.add("carriage");

        System.out.println("********************************* fst call on full list *********************************");
        printList(vehicles);

        System.out.println("********************************* from iterator *********************************");
        Iterator<String> itr = vehicles.iterator();
        while(itr.hasNext()) {
            Object elemental = itr.next();
            if (elemental.equals("carriage")) {
                itr.remove();
            }
            System.out.println(elemental);
        }

        System.out.println("********************************* snd call on list *********************************");
        for (String item : vehicles) {
            System.out.println(item);
        }

        System.out.println("********************************* List from insertVeh method *********************************");
        LinkedList <String> rovers = new LinkedList <> ();
        rovers = (LinkedList<String>) listproc.insertVeh("Stagecoach", vehicles);

        System.out.println("********************************* trd call on list *********************************");
        printList(rovers);

    }

    private static void printList(List<String> list) {

        for (String item : list) {
            System.out.println(item);
        }

    }
}
