package Zadatak5;

import java.util.List;
import java.util.ListIterator;

public class ListProcessing {
    List<String> insertVeh(String str, List <String> list) {

        ListIterator <String> itr = (ListIterator<String>) list.iterator();

        for (String item : list) {
            System.out.println(item);
        }
        while(itr.hasNext()) {
            Object elemental = itr.next();
            if (elemental.equals("electronic bike")) {
                itr.add(str);
            }

        }
        return list;

    }
}
