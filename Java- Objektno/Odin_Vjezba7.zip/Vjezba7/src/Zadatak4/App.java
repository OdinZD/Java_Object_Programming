package Zadatak4;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Scanner;

public class App {
    public static void main(String[] args) {

        LinkedList <String> list = new LinkedList <> ();

        File file = new File("src/Zadatak4/odin.txt");

        Scanner sc = null;

        try {
            sc = new Scanner(file);
        } catch (FileNotFoundException e) {

            e.printStackTrace();
        }

        while (sc.hasNextLine()) {
            list.add(sc.nextLine());
        } sc.close();

        System.out.println("****** Ispis liste ******");
        System.out.println(list);
        for (String item : list) {
            System.out.println(item);
        }

        Collections.sort(list, new SortPoDuljini());

        System.out.println("++++ Ispis prema duljini stringa ++++");
        for (String item : list) {
            System.out.println(item);
        }

    }

}

