package Zadatak3;

import java.util.concurrent.ArrayBlockingQueue;

public class App {

    static ArrayBlockingQueue<Integer> red = new ArrayBlockingQueue <> (5);

    public static void main(String[] args) {

        try {
            red.add(1);
            red.add(2);
            red.add(3);
            red.add(4);
            red.add(5);

            System.out.println("++++ Originalan red ++++");
            // Ispis reda cekanja
            for (Integer item : red) {
                System.out.println(item);
            }

            red.add(6);

        } catch (IllegalStateException e) {
            System.out.println("Ne mozete dodavati vise elemenata u red cekanja nego sto je definirano!");
            System.out.println("Queue full");
        }

        process(1);
        recieve(12);

    }

    private static boolean process(int flag) {

        if (flag == 1) {
            System.out.println("Obrada u tijeku!");
            red.poll();
            System.out.println("++++ Red bez prvog elementa ++++");
            for (Integer item : red) {
                System.out.println(item);
            }

            return true;
        } else {
            return false;
        }
    }

    private static void recieve(int num) {

        red.add(num);

        System.out.println("++++ Red s novim elementom na kraju reda ++++");
        for (Integer item : red) {
            System.out.println(item);
        }

    }

}
