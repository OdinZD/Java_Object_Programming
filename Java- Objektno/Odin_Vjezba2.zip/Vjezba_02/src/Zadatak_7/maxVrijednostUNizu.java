package Zadatak_7;
//Generirajte proizvoljni 2D niz tipa int (3x4), te pronađite i ispišite maksimalnu vrijednost u nizu.
import java.util.Arrays;
import java.util.concurrent.ThreadLocalRandom;

public class maxVrijednostUNizu {

	public static void main(String[] args) {
		int[][] vars = new int[3][4];

		int redci = vars.length;
		int stupci = vars[0].length;

		int min = 1; int maks = 100;

		for (int i = 0; i < redci; i++) {
			for (int j = 0; j < stupci; j++) {
				vars[i][j] = ThreadLocalRandom.current().nextInt(min, maks);
			}
		}

		int max = vars[0][0];
		for (int i = 0; i < redci; i++) {
			for (int j = 0; j < stupci; j++) {
				if (max < vars[i][j])
					max = vars[i][j]; 
			}
		}

		System.out.println("Niz 3 x 4: ");
		for (int[] rw : vars) {
			System.out.println(Arrays.toString(rw)); 
		}

		System.out.println();
		System.out.print("Maksimalna vrijednost u nizu je: " + max);

	}

}
