package Zadatak_3;
//zmijenite kod na način da umjesto petlje for each upotrijebite klasičnu for petlju. 
//U tom slučaju prvo stavite u komentar na cijelu for each petlju → označite taj dio koda → desni klik i iz skočnog izbornika izaberite Source, a zatim Toggle Comment
import java.util.concurrent.ThreadLocalRandom;

public class fromForEachToFor {

	public static void main(String[] args) {
		// deklariranje i inicijalizacija 2D niza
				double[][] vars = new double[3][5];
				int nrows = vars.length;
				int nclmns = vars[0].length;
				double min = 500.45;
				double max = 12578.32;

				// popunjavanje vrijednosti 2D niza
				for (int i = 0; i < nrows; i++) {
					for (int j = 0; j < nclmns; j++) {

						// Generiranje slučajne vrijednosti između zadanih granica
						vars[i][j] = ThreadLocalRandom.current().nextDouble(min, max);
					}
				}

				// For each petlja

				/* Arrays je ugrađena JAVA klasa koja nudi čitav niz korisnih metoda za manipulaciju, odnosno rad s nizovima.
				 * Metoda te klase toString vraća String prikaz sadržaja niza. */

//				for (double[] rw : vars) {
//					System.out.println(Arrays.toString(rw)); 
//				}

				// Još jedan način za ispis
				for (int i = 0; i < vars.length; i++) {
					for (int j = 0; j < vars[0].length; j++) {
						System.out.println(vars[i][j]);
					}
				}


	}

}
