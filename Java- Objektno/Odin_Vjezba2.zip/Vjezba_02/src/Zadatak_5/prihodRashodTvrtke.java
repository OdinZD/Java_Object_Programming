package Zadatak_5;

//Zadani su podaci u priloženoj tablici na Slici 4. Podaci predstavljaju prihode i rashode neke tvrtke po mjesecima. Potrebno je:

//Izračunati profite po mjesecima kao razliku prihoda i rashoda (vodite računa o predznaku)
//Prosječni profit tvrtke za promatranu godinu
//Ispišite sve tražene vrijednosti s pripadajućim tekstulanim objašnjenjima


public class prihodRashodTvrtke {

	public static void main(String[] args) {
		int suma = 0;
		int mjesecno = 0;

		int[][] tvrtka= new int[][] { {125855, 105625}, {284569, 155748}, {324152, 198455}, {204563, 195251}, {452198, 257654}, {471326, 322188},
			{505169, 355748}, {498569, 315782}, {367163, 389455}, 	{289568, 302369}, {115255, 109854}, {98544, 85223} 	};

			for (int redak = 0; redak < tvrtka.length; redak++) {    
				for (int stupac = 0; stupac < tvrtka[redak].length; stupac++) {
					mjesecno = tvrtka[redak][0]-tvrtka[redak][1];
				}
				suma += mjesecno;
				System.out.println("Profit za " + (redak + 1) +"."+ " mjesec iznosi: " + mjesecno + " kn");
			}   

			System.out.println("----------------------------------------");
			System.out.println("Ukupni godisnji profit iznosi: "+ suma + " kn");
			System.out.println("Prosjecni mjesecni profit iznosi: "+ suma / tvrtka.length + " kn");

	}

}
