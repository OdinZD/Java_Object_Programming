package Zadatak_8;
import java.util.Arrays;
import java.util.concurrent.ThreadLocalRandom;

public class jednoDimNIz {

	public static void main(String[] args) {
		double[] niz = new double[15];
		double minDo = 25.78; double maxDo = 2400.89;

		for (int i = 0; i < niz.length; i++) {
			niz[i] = ThreadLocalRandom.current().nextDouble(minDo, maxDo);
		}

		System.out.println("Nesortirani niz: ");
		for (double item : niz) {
			System.out.print(String.format( "%.2f" + ", ", item));
		}

	}

}
