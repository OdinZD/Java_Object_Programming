package Zadatak_1;
//Potrebno je napisati program koji će kreirati dva String niza: jedan određen sa sljedećim elementima "Vasa" "vana plurimum" "sonant" i drugi za kojeg ćete rezervirati 4 mjesta,
// a koja ćete popuniti korisničkim unosom. 
//Ispišite prvi niz spajanjem sva tri elementa uz pripadajuće razmake (concatenation), 
//a drugi navođenjem jednog ispod drugog.

import java.util.Scanner;

public class KreiranjeDvaStringa {

	public static void main(String[] args) {
		String[] niz1 = {"Vasa", "vana plurium", "sonant"};
		String[] niz2 = new String[4];

		Scanner unos = new Scanner(System.in);

		for (int i = 0; i < niz2.length; i++) {
			System.out.println("Unesi broj: ");
			niz2[i] = unos.nextLine();
		}

		for (String item : niz1) {
			System.out.print(item + " ");
		}

		System.out.println();
		for (String item : niz2) {
			System.out.println(item);
		}
		
		unos.close();

	}

}
