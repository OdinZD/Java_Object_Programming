package Zadatak_2;

import java.util.Scanner;

//Program koji će računati prosjek temperatura za dani broj mjerenja.
//Izračunajte koliko izmjerenih vrijednosti je bilo ispod, a koliko iznad prosječne vrijednosti. Na samom kraju ispišite vrijednost prosječne temperature i ukupni broj mjerenja, te broj mjerenja s temperaturom ispod, 
//odnosno iznad prosječne vrijednosti.
public class RacunanjeTemp {

	public static void main(String[] args) {
		int broj_mjerenja;
		double suma = 0;

		Scanner unos = new Scanner(System.in);

		System.out.println("Unesi broj mjerenja: ");
		broj_mjerenja = unos.nextInt();

		float[] temperature = new float[broj_mjerenja];

		for (int i = 0; i < temperature.length; i++) {
			System.out.println("Unesi temperaturu: ");
			temperature[i] = unos.nextFloat();
		}

		for (int i = 0; i < temperature.length; i++) {
			suma = suma + temperature[i]; // Zbrajamo sve unesene temperature
		}

		double prosjek = suma / broj_mjerenja; // Izračunavamo prosječnu temperaturu

		int brojac_visa = 0;
		int brojac_niza = 0;

		for (int i = 0; i < temperature.length; i++) {
			if (temperature[i] > prosjek) {
				brojac_visa++;
			} else {
				brojac_niza++;
			}
		}

		System.out.println("Prosjecna temperatura iznosi: " + prosjek + " °C");
		System.out.println("Broj mjerenja: " + broj_mjerenja);
		System.out.println("Broj mjerenja s temperaturom iznad prosjecne vrijednosti: " + brojac_visa);
		System.out.println("Broj mjerenja s temperaturom ispod prosjecne vrijednosti: " + brojac_niza);
		
		unos.close();

	}

}
