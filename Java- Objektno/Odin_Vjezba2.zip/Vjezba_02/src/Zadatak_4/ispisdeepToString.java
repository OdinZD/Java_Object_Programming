package Zadatak_4;

//Riješite raniji primjer 2D niza na način da ispis niza ne vršite ni for each petljom ni for petljom već ugrađenom funkcijom deepToString.
//Koji je nedostatak tako dobivenog ispisa?
import java.util.Arrays;
import java.util.concurrent.ThreadLocalRandom;

public class ispisdeepToString {

	public static void main(String[] args) {
		double[][] vars = new double[3][5];
		int nrows = vars.length;
		int nclmns = vars[0].length;
		double min = 500.45;
		double max = 12578.32;

		for (int i = 0; i < nrows; i++) {
			for (int j = 0; j < nclmns; j++) {

				vars[i][j] = ThreadLocalRandom.current().nextDouble(min, max);
			}
		}

		System.out.println(Arrays.deepToString(vars));
	}

}
