package Zadatak_6;
//Kreirajte proizvoljni niz tipa int duljine 15. Izradite kopiju tog niza (copyOf) i potom provjerite jednakost nizova primjenom ugrađene funkcije equals. Ispišite pripadnu poruku rezultata provjere.
import java.util.Arrays;
import java.util.concurrent.ThreadLocalRandom;

public class jednakostNiza {

	public static void main(String[] args) {
		int[] niz1 = new int[15];

		int minIn = 10; 	int maxIn = 98; 

		for (int i = 0; i < niz1.length; i++) {
			niz1[i] = ThreadLocalRandom.current().nextInt(minIn, maxIn + 1);
		}

		int [] niz2 = Arrays.copyOf(niz1, 15);

		System.out.println("Proizvoljni niz: ");
		for (int rw : niz1) {
			System.out.print(rw + " ");
		}

		System.out.println();
		System.out.println("Kopija niza: ");
		for (int rw : niz2) {
			System.out.print(rw + " ");
		}

		System.out.println();
		System.out.print(niz1.equals(niz2));

		System.out.println();
		System.out.println("Da li je proizvoljni niz jednak kopiji tog niza ");
		if (niz1.equals(niz2)) {
			System.out.println("Je");
		} else {
			System.out.println("Nije");
		}

	}

}
