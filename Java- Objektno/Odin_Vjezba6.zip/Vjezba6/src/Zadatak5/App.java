package Zadatak5;

import java.util.ArrayList;
import java.util.Collections;

public class App {

    public static void main(String[] args) {
        ArrayList<String> arr = new ArrayList<>();

        arr.add("auto");
        arr.add("svemirski brod");
        arr.add("avion");
        arr.add("helikopter");
        arr.add("jedrilica");
        arr.add("gliser");
        arr.add("romobil");
        arr.add("bicikla");

        System.out.println("*********** Nesortirano ***********");
        for (String item : arr) {
            System.out.println(item);
        }

        Collections.sort(arr);

        System.out.println("*********** Sortirano po abecedi ***********");
        for (String item : arr) {
            System.out.println(item);
        }

        // U glavnom dijelu programa sortirate
        Collections.sort(arr, new LengthStrComparator());

        System.out.println("*********** Sortirano po duljini stringa ***********");
        for (String item : arr) {
            System.out.println(item);
        }


    }
}


