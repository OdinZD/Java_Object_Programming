package Zadatak3;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class App {
    public static void main(String[] args) {

        HashSet<String> hshst = new HashSet<>();
        TreeSet<String> trst = new TreeSet<>();
        LinkedHashSet<String> lhshst = new LinkedHashSet<>();

        fillSet(hshst);
        fillSet(trst);
        fillSet(lhshst);

        testForElement(hshst, "Nema ga");
        testForElement(trst, "Nema ga");
        testForElement(lhshst, "Nema ga");

        System.out.println("******* HashSet *******");
        printSet(hshst);
        System.out.println("******* TreeSet *******");
        printSet(trst);
        System.out.println("******* LinkedHashSet *******");
        printSet(lhshst);

        hshst.add("Nema ga");
        trst.add("Nema ga");
        lhshst.add("Nema ga");

        eraseAnyElement(lhshst, "Linux");

        System.out.println("******* HashSet *******");
        printSet(hshst);
        System.out.println("******* TreeSet *******");
        printSet(trst);
        System.out.println("******* LinkedHashSet *******");
        printSet(lhshst);

    }

    // Metoda za dodavanje 5 proizvoljnih stringova
    public static void fillSet(Set <String> st) {

        st.add("Otvoreni");
        st.add("Kod");
        st.add("Kriptografija");
        st.add("Linux");
        st.add("Kriptirani");

    }

    // Metoda koja provjerava da li je element u skupu
    public static boolean testForElement(Set<String> st, String element) {

        if (st.contains(element)) {
            System.out.println("Set contains element: " + element);
            return true;

        } else {
            System.out.println("Set doesn't contains element: " + element);
            System.out.println("So I'm adding element: " + element);
            st.add(element);
            return false;
        }

    }

    // Metoda koja brise iz bilo kojeg skupa zeljeni element
    public static void eraseAnyElement(Set <String> st, String element) {

        if (testForElement(st, element)) st.remove(element);

    }

    // Metoda za ispis clanova skupa
    public static void printSet(Set <String> st) {

        for (String item : st) {
            System.out.println(item);
        }

    }
}
