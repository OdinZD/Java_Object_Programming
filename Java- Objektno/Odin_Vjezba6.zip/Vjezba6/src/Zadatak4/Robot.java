package Zadatak4;

public class Robot {

    public int id;
    public String opis;

    public Robot(int id, String opis) {

        this.id = id;
        this.opis = opis;

    }

    // Metoda za ispis Generika Robot kod Set-a
    @Override
    public String toString() {
        return "[Robot id = " + id + ", description = " + opis + "]";
    }

    public String getOpis() {
        return opis;
    }


    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + id;
        result = prime * result + ((opis == null) ? 0 : opis.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Robot other = (Robot) obj;
        if (id != other.id)
            return false;
        if (opis == null) {
            if (other.opis != null)
                return false;
        } else if (!opis.equals(other.opis))
            return false;
        return true;
    }
}
