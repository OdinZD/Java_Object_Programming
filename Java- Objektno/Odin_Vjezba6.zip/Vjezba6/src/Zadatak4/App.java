package Zadatak4;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;

public class App {
    public static void main(String[] args) {

        Robot flying_robot = new Robot(126, "flying robot");
        Robot cleaning_robot = new Robot(5647, "cleaning robot");
        Robot thinking_robot = new Robot(7857, "thinking robot");
        Robot humorous_robot = new Robot(7, "humorous robot");
        Robot friendly_robot = new Robot(896, "friendly robot");
        Robot weird_robot = new Robot(3214, "weird robot");

        LinkedHashMap<Robot, String> map = new LinkedHashMap<>();

        map.put(flying_robot, flying_robot.getOpis());
        map.put(cleaning_robot, cleaning_robot.getOpis());
        map.put(thinking_robot, thinking_robot.getOpis());
        map.put(humorous_robot, humorous_robot.getOpis());
        map.put(friendly_robot, friendly_robot.getOpis());
        map.put(weird_robot, weird_robot.getOpis());

        Robot weird_robot_copy = new Robot(3214, "weird robot");

        map.put(weird_robot_copy, weird_robot_copy.getOpis());

        LinkedHashSet<Robot> set = new LinkedHashSet<>();

        set.add(flying_robot);
        set.add(cleaning_robot);
        set.add(thinking_robot);
        set.add(humorous_robot);
        set.add(friendly_robot);
        set.add(weird_robot);

        set.add(weird_robot_copy);

        System.out.println("********************* MAP *********************");
        for (Robot key : map.keySet()) {
            System.out.println(key);
        }

        System.out.println();
        System.out.println("********************* SET *********************");
        for (Robot item : set) {
            System.out.println(item.toString());
        }

    }
}
