package Zadatak2;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class App {
    public static void main(String[] args) {

        HashMap<Integer, String> hsmp = new HashMap<>();

        hsmp.put(21, "Stipe");
        hsmp.put(159, "Divna");
        hsmp.put(985, "Etna");
        hsmp.put(455, "Petar");
        hsmp.put(5788, "Vlatka");

        // ispis po kljucevima
        for (Integer key : hsmp.keySet()) {
            System.out.println("id = " + key + " Name = " + hsmp.get(key));
        }

        TreeMap<Integer, String> trmp = new TreeMap<>(hsmp);

        System.out.println();
        System.out.println("********** Tree Map **********");

        printMap(trmp);

        LinkedHashMap<Integer, String> lhmp = new LinkedHashMap<>(hsmp);

        System.out.println();
        System.out.println("********** Linked Hash Map **********");

        printMap(lhmp);

    }

    public static void printMap(Map<Integer, String> mp) {

        for (Integer key : mp.keySet()) {
            System.out.println("id = " + key + " Name = " + mp.get(key));
        }

    }

}
