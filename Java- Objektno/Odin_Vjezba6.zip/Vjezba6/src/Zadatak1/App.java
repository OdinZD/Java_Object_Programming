package Zadatak1;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class App {
    public static void main(String[] args) {

        ArrayList<String> arlist = new ArrayList<>();

        arlist.add("Python");
        arlist.add("Java");
        arlist.add("C#");
        arlist.add("Dart");
        arlist.add("C++");

        LinkedList<String> linklist = new LinkedList<>();

        linklist.addAll(arlist);

        System.out.println("********** ArrayList **********");
        System.out.println(arlist);
        System.out.println();
        System.out.println("********** LinkedList **********");
        System.out.println(linklist);

        linklist.addLast("Swift");

        linklist.addFirst("PHP");
        linklist.addLast("JavaScript");

        System.out.println();
        System.out.println("********** Ext LinkedList **********");
        for (String item : linklist) {
            System.out.println(item);
        }

        swapElement(linklist, 3, "Neki novi jezik");

    }

    public static void swapElement (List<String> list, int index, String element) {

        String erased = list.get(index);
        list.set(index, element);

        System.out.println();
        System.out.println("********** After method **********");
        System.out.println(list);

        System.out.println("********** Erased element **********");
        System.out.println(erased);

    }

}
