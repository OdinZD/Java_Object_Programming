public class DS_Student extends Student{

    public DS_Student(String ime, int id) {
        this.name = ime;
        this.idStud = id;

    }
    @Override
    public boolean completingStudy(int year) {
        if (year < 2 ) {
            System.out.println("nije upisana posljednja godina studija.");
        }
        return false;
    }

    @Override
    public void infoStud() {
        super.infoStud();
        System.out.println("Diplomski studija");
    }
}
