/* Kreiranje Override-a, 1. completingStudy naslijedio od nadklase Student,
/* 2. infoStud desni klik na prazno, pa Source, pa Override / Implement Methods..., pa klik
/* na metodu koju želimo Overrideati, važno je da je klasa koju proširujemo apstraktna */
public class PDS_Student extends Student{


    public PDS_Student (String ime, int id) {
        this.name = ime; // Ovo je trebalo extra ubaciti
        this.idStud = id; // Također i ovo, trebalo je gore staviti umisto name ime i umisto idStud id
    }
    @Override
    public boolean completingStudy(int year) {
        if (year < 3) {
            System.out.println("Nije upisana poslijednja godina studija");
        }
        return false;
    }
    /* Za proširenje metode infoStud želimo da metoda ispise isto što i istoimena metoda apstraktne
     * klase super.infoStud(), te dodatnu poruku koja kaže na kojem studiju je student (preddiplomski / diplomski) */

    @Override
    public void infoStud() {
        super.infoStud();
        System.out.println("Preddiplomskli studij");
    }
}
