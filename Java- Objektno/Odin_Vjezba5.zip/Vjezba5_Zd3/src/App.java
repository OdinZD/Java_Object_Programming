import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {

        Paket pck = new Paket();
        Scanner sc = new Scanner(System.in);
        String payM = "";

        // Pozivanje unutarnje klase
        Paket.Helmet hlm = pck.new Helmet();

        // Odabir Payment Method
        pck.setPaymentMeth(payM);
        boolean yes = pck.checkPaymentPackage();

        pck.setCustomerID(12354);
        pck.setDestination("Zadar");
        pck.setIdPack(11);
        pck.setSellCompany("BestCompany");

        int cnt = 0;

        // Ovdje uvjet ispitivati --> npr. while(pck.checkPaymentPackage()....)
        // Dok nije unesen pravi način plaćanja
        while (yes != true) {

            cnt++;
            System.out.println("This is attempt: " + cnt);
            System.out.println("Attempts left: " + (4 - cnt));
            payM = sc.nextLine();
            pck.setPaymentMeth(payM);

            // Ako je metoda vraća true (odnosno dobar način plaćanja)
            if (pck.checkPaymentPackage() == true) {
                // Prekida se
                yes = true;
                // Ako nije: nastavlja se
            } else {
                yes = false;
            }
            // Dok nisu 4 puta unesena pogrešna naèina plaæanja; nastavak na 39
            if (cnt == 4) {
                break;
            }

        }
        sc.close();

        // Namještamo cijenu paketa preko Metode putContent()
        pck.setPricePackage(pck.putContent());

        // Ako je ispravna metoda plaćanja nakon while zapakiraj paket i pošalji ga
        if (yes == true) {
            pck.sentPackage();

            // U protivnom cijenu postavi na 0 i ispiši poruku o nemoguænosti slanja paketa zbog greške u plaæanju
        } else {
            pck.setPricePackage(0);
            System.out.println("Nemoguænost slanja paketa zbog greške u plaæanju!");
            System.out.println("Cijena paketa zbog svega toga " + pck.getPricePackage() + " €");
        }

    }

}
