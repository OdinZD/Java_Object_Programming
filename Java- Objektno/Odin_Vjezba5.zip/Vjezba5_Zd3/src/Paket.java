public class Paket {

    private int idPack;
    private String destination;
    private int customerID;
    private String sellCompany;
    private String paymentMeth;
    private float pricePackage;
    private int kom;

    public Paket() {

    }

    public int getKom() {
        return kom;
    }

    public int getIdPack() {
        return idPack;
    }

    public void setIdPack(int idPack) {
        this.idPack = idPack;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public int getCustomerID() {
        return customerID;
    }

    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }

    public String getSellCompany() {
        return sellCompany;
    }

    public void setSellCompany(String sellCompany) {
        this.sellCompany = sellCompany;
    }

    public String getPaymentMeth() {
        return paymentMeth;
    }

    public void setPaymentMeth(String paymentMeth) {
        this.paymentMeth = paymentMeth;
    }

    public float getPricePackage() {
        return pricePackage;
    }

    public void setPricePackage(float pricePackage) {
        this.pricePackage = pricePackage;
    }

    // Kreira objekte unutarnjih klasa i daje ukupnu cijenu paketa
    public float putContent() {

        Helmet hlm = new Helmet(199, 2);
        Pants pnts = new Pants(13, 2);
        Sneakers snkr = new Sneakers(14, 3);
        Tshirt tsh = new Tshirt(15, 4);

        System.out.println("Kaciga:: cijena: " + hlm.priceHelmet() + " , komada: " + hlm.getKomHelmet());

        return 382.05002f;

    }

    public boolean checkPaymentPackage() {

        class PaymentMedia {

            final static String POU = "POU";
            final static String CP = "CP";
            final static String OPS = "OPS";

            boolean payPackage() {

                switch (paymentMeth) {

                    case POU:
                        System.out.println("Payment will be made to a courier service ... ");
                        System.out.println("Package with id: " + idPack + ", payed by customer with id: " + customerID);
                        System.out.println("\n");
                        return true;
                    case CP:
                        System.out.println("Payment is done with credit card ...");
                        System.out.println("Package with id: " + idPack + ", payed by customer with id: " + customerID);
                        System.out.println("\n");
                        return true;
                    case OPS:
                        System.out.println("Payment is done by online payment service ...");
                        System.out.println("Package with id: " + idPack + ", payed by customer with id: " + customerID);
                        System.out.println("\n");
                        return true;
                    default:
                        System.out.println("Please choose a valid payment method ...");
                        System.out.println("\n");
                        return false;
                }
            }

            void paymentPossible() {

                System.out.println("Possible payment methods:");
                System.out.println(POU);
                System.out.println(CP);
                System.out.println(OPS);

            }

        }

        // Inicijalizacija Klase unutar metode
        PaymentMedia pay = new PaymentMedia();

        // Odreðuje true ili false Metode payPackage()
        boolean yes = pay.payPackage();

		/* Ako nije unesen pravi naèin plaæanja nudi opcije plaæanja odnosno
		Metoda paymentPossible() */
        if (yes == false) {
            pay.paymentPossible();
        }
        return yes;
    }

    public void sentPackage() {

        System.out.println("Package: " + idPack + ", sent to customer with id: " + customerID);
        System.out.println("Customer destination: " + destination);
        System.out.println("Package price: " + pricePackage + " €");

    }

    class Helmet {

        float price;
        int kom;

        public Helmet(float price, int kom) {
            this.price = price;
            this.kom = kom;
        }

        public Helmet() {}

        int getKomHelmet() {
            return kom;
        }

        float priceHelmet() {
            return price;
        }

    }

    class Pants {

        float price;
        int kom;

        public Pants(float price, int kom) {
            this.price = price;
            this.kom = kom;
        }

        float pricePant() {
            return price;
        }

    }

    class Sneakers {

        float price;
        int kom;

        public Sneakers(float price, int kom) {
            this.price = price;
            this.kom = kom;
        }

        float priceSneakers() {
            return price;
        }

    }

    class Tshirt {

        float price;
        int kom;

        public Tshirt(float price, int kom) {
            this.price = price;
            this.kom = kom;
        }

        float priceTshirt() {
            return price;
        }

    }

}
