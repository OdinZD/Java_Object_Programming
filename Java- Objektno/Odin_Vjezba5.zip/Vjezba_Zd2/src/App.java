import java.text.ParseException;

public class App {

    public static void main(String[] args) throws ParseException {
        Robot rob = new Robot();

        rob.setName("Roby");
        rob.setIdRob(45126);

        Person prs = new Person("Roberta", "22/12/1997");

        prs.think("Life");
        rob.think("Life");
        prs.walk("North", 50);
        rob.walk("South", 123);

        System.out.println("********** Izracuni **************");

        System.out.println(prs.calculate(8));
        System.out.println(rob.calculate(6));

    }
}
