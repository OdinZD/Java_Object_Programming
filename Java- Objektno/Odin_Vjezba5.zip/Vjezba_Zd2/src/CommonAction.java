public interface CommonAction {

    public void walk (String s, int n) ;

    public String talk ();
    public void think (String s);
    public int calculate (int n);
}

