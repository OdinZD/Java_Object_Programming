import java.text.DateFormat;
import java.util.Date;
import java.util.UUID;

public class Person implements CommonAction{

    private String name;
    private Date dob;
    private DateFormat df;

    public Person(String str1, String str2){

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public DateFormat getDf() {
        return df;
    }

    public void setDf(DateFormat df) {
        this.df = df;
    }

    @Override
    public void walk(String s, int n) {
        System.out.println("I'm human, and u can't command to me!");
    }

    @Override
    public String talk() {
        System.out.println("You want me to talk - ok: ");
        return UUID.randomUUID().toString();
    }

    @Override
    public void think(String s) {
        System.out.println("Surely, humans are more capable of thinking then robots - aren't they?");
    }

    @Override
    public int calculate(int n) {
        return n%2;
    }
    public void infoPerson(String name, int dob) {
        System.out.println(name + dob);
    }
}

