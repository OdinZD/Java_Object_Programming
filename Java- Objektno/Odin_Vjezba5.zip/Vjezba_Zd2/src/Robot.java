import java.util.UUID;

public class Robot implements CommonAction{

    private int idRob;
    private String name;

    public Robot(){

    }
    public void infoRobot(){
        System.out.println(name + idRob);
    }

    public int getIdRob() {
        return idRob;
    }

    public void setIdRob(int idRob) {
        this.idRob = idRob;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public void walk(String s, int n) {
        System.out.println("I m walking in direction of "+ s + ", and travel distance is: "+ n);
    }

    @Override
    public String talk() {
        System.out.println("This robot can't speak!" );
        return UUID.randomUUID().toString();
    }

    @Override
    public void think(String s) {
        System.out.println("Thinking...");
    }

    @Override
    public int calculate(int n) {
        if (n < 2) {
            return n;

        }else {
            return calculate( n - 1)* n;
        }
    }
}
