package Zadatak_3;

import java.util.Scanner;

public class VolumeKugleWhile {

	
	
	public static void main(String[] args) {
		double r = 0;
		double V;
		Scanner sc = new Scanner(System.in);
		
		while (r<10) {
			System.out.println("Unesi polumjer kugle: ");
			
			r = sc.nextDouble();
			V = (4*Math.pow(r, 3)*Math.PI*4/3);
			
			
			if (r>=10) {
				System.out.println("Polumjer kruga je veci od 10!");
			}else {
				System.out.println("Volumen kugle je: " + V);
			}
			
		}
		sc.close();
	}

}
