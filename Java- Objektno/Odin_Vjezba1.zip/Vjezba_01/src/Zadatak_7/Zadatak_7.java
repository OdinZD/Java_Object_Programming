package Zadatak_7;

import java.util.Scanner;

public class Zadatak_7 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Unesi string: ");
		String unos = scanner.nextLine();
		
		if (unos.equalsIgnoreCase("dobro")) 
			System.out.print("Hvala, danas sam " + unos); 
		else if (unos.equalsIgnoreCase("bolje"))
			System.out.print("Hvala, danas sam " + unos);		
		else if (unos.equalsIgnoreCase("najbolje"))
			System.out.print("Hvala, danas sam " + unos);
		else
			System.out.println("Sigurno �e biti bolje :-).");
		
		scanner.close();

	}

}
