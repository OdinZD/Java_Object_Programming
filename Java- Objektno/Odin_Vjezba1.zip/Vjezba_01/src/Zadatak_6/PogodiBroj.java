package Zadatak_6;

import java.util.Scanner;

public class PogodiBroj {

	public static void main(String[] args) {
		int r;
		
		Scanner sc = new Scanner(System.in);
		
		do {
			System.out.println("Unesite broj: ");
			r = sc.nextInt();
			System.out.println("Unijeli ste broj: " + r);
		} while (r != 158);
		
		if (r == 158)
			System.out.println("Bingo!");
		sc.close();


	}

}
