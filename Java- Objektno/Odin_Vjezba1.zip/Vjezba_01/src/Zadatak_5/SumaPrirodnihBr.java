package Zadatak_5;

import java.util.Scanner;

public class SumaPrirodnihBr {

	public static void main(String[] args) {
		int sum = 0;
		int n;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Upisi jedan broj: ");
		n = sc.nextInt();
		
		for (int i = 1; i <= n; i++) {
			sum = sum + i;
		}
		
		System.out.println("Suma unesenih brojeva N: " + sum);
		sc.close();

	}

}
