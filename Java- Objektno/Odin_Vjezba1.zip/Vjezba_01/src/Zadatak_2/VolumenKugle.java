package Zadatak_2;

import java.util.Scanner;

public class VolumenKugle {

	public static void main(String[] args) {
		double r;
		double V;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Unesi polumjer: ");
		
		r = sc.nextInt();
		
		V = Math.pow(r, 3)*Math.PI*4/3;
		
		System.out.println("Volumen kugle: " + V);
		
		sc.close();
	}

}
